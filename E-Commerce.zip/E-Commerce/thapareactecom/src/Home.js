
import HeroSection from "./components/HeroSection";




const Home = () => {
  const data = {
    name: "SPIDEY's  Store",
  };

  return (
    <>
      <HeroSection myData={data} />
     
     
    </>
  );
};

export default Home;