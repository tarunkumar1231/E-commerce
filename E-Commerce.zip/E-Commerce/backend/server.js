const express = require('express');
const mysql = require('mysql');

const app = express();
const PORT = 8081;
const cors = require('cors');
app.use(cors());

// Create a MySQL connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'debrup'
});

// Connect to the database
db.connect((err) => {
    if (err) {
        console.error('Error connecting to MySQL:', err);
        return;
    }
    console.log('Connected to MySQL');
});

// Middleware to parse JSON requests
app.use(express.json());

// POST endpoint to handle signup
/*app.post('/signup', (req, res) => {
    const { name, email, password } = req.body;

    const sql = 'INSERT INTO `login1` (`name`, `email`, `password`) VALUES (?, ?, ?)';
    const values = [name, email, password];

    db.query(sql, values, (err, result) => {
        if (err) {
            console.error('Error inserting into database:', err);
            return res.status(500).json({ error: 'Internal Server Error' });
        }
        console.log('Inserted into database:', result);

        // Assuming you want to send a success response to the client
        res.status(200).json({ success: true });
    });
});

// Start the server
*/
app.post('/login', (req, res) => {
    const { name, email, password } = req.body;

    const sql = 'INSERT INTO `login(1)` (`name`, `email`, `password`) VALUES (?, ?, ?)';
    const values = [name, email, password];

    db.query(sql, values, (err, result) => {
        if (err) {
            console.error('Error inserting into database:', err);
            return res.status(500).json({ error: 'Internal Server Error', details: err.message });
        }

        console.log('Inserted into database:', result);

        // Assuming you want to send a success response to the client
        res.status(200).json({ success: true });
    });
});
/*app.post('/as', (req, res) => {
    const { name, email, password } = req.body;

    const sql = 'INSERT INTO `admin` (`name`, `email`, `password`) VALUES (?, ?, ?)';
    const values = [name, email, password];

    db.query(sql, values, (err, result) => {
        if (err) {
            console.error('Error inserting into database:', err);
            return res.status(500).json({ error: 'Internal Server Error', details: err.message });
        }

        console.log('Inserted into database:', result);

        // Assuming you want to send a success response to the client
        res.status(200).json({ success: true });
    });
}); */


app.post(`/userlogin`, (req, res) => {
    const sql = "SELECT * FROM `login(1)` WHERE email = ? AND password = ?";
    db.query(sql, [req.body.email, req.body.password], (err, data) => {
        if(err){
            return res.json("Error");
        }
        if(data.length > 0) {
            return res.json("Success")
        } else {
            return res.json("Failed")
        }
    });
});
/*app.post(`/al`, (req, res) => {
    const sql = "SELECT * FROM admin WHERE email = ? AND password = ?";
    db.query(sql, [req.body.email, req.body.password], (err, data) => {
        if(err){
            return res.json("Error");
        }
        if(data.length > 0) {
            return res.json("Success")
        } else {
            return res.json("Failed")
        }
    });
});*/
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
